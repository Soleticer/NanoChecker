# Nano Checker

Android app to check Gemini Nano status using Google ML Kit Prompt API and request an official model download **only if** the status is DOWNLOADABLE.

## Cloud build
1. Create a GitHub repository and upload the contents of this ZIP to its root.
2. Open Actions > Build Nano Checker APK > Run workflow (or push triggers build).
3. Download the NanoChecker-debug-apk artifact, unzip, and install app-debug.apk on Android.

The APK is not prebuilt or verified. GitHub Actions must compile it. No root/Shizuku needed. If status is UNAVAILABLE, this app cannot bypass device eligibility.

Official API documentation: https://developers.google.com/ml-kit/genai/prompt/android/get-started
