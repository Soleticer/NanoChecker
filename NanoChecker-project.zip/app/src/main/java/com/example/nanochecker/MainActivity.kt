package com.example.nanochecker

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.genai.prompt.Generation
import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.common.DownloadStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val model by lazy { Generation.getClient() }
    private lateinit var output: TextView
    private lateinit var downloadButton: Button
    private fun show(s: String) { output.append("\n" + s) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(30, 40, 30, 20) }
        val check = Button(this).apply { text = "Проверить Gemini Nano" }
        downloadButton = Button(this).apply { text = "Загрузить модель"; isEnabled = false }
        output = TextView(this).apply { textSize = 17f; text = "Nano Checker — ML Kit Prompt API" }
        layout.addView(check); layout.addView(downloadButton); layout.addView(output)
        setContentView(ScrollView(this).apply { addView(layout) })
        check.setOnClickListener {
            downloadButton.isEnabled = false
            show("Проверка...")
            scope.launch {
                try {
                    val status = model.checkStatus()
                    show("Статус: " + when(status) {
                        FeatureStatus.AVAILABLE -> "AVAILABLE — модель доступна"
                        FeatureStatus.DOWNLOADABLE -> "DOWNLOADABLE — можно загрузить"
                        FeatureStatus.DOWNLOADING -> "DOWNLOADING — уже загружается"
                        FeatureStatus.UNAVAILABLE -> "UNAVAILABLE — недоступна на устройстве"
                        else -> "Неизвестный статус: $status"
                    })
                    downloadButton.isEnabled = status == FeatureStatus.DOWNLOADABLE
                } catch (e: Exception) { show("Ошибка проверки: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }
        downloadButton.setOnClickListener {
            downloadButton.isEnabled = false
            scope.launch {
                try {
                    model.download().collect { status ->
                        when(status) {
                            is DownloadStatus.DownloadStarted -> show("Начало загрузки: ${status.bytesToDownload} байт")
                            is DownloadStatus.DownloadProgress -> show("Загружено: ${status.totalBytesDownloaded} байт")
                            DownloadStatus.DownloadCompleted -> show("Загрузка завершена!")
                            is DownloadStatus.DownloadFailed -> show("Ошибка загрузки: ${status.e.message}")
                        }
                    }
                } catch (e: Exception) { show("Ошибка: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }
    }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
